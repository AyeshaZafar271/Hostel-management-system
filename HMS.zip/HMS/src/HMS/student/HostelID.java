package HMS.student;


import HMS.connection.ConnectionHandler;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ayesha Zafar
 */
public class HostelID {

    /**
     * @param args the command line arguments
     */
    Connection con = null;
    ConnectionHandler h=new ConnectionHandler();
     int getValue;
    public void generateHostelID(String query) throws Exception{
      con=h.getConnection();
     
            
        try {
            Statement s=con.createStatement();
            ResultSet rs=s.executeQuery(query);
            if(rs.next()){
                getValue=Integer.parseInt(rs.getString(1));
            }
        } catch (SQLException ex) {
             System.out.println(ex);
              System.out.println("exception while generating id");
        }
    }
    public String getID() throws Exception{
        generateHostelID("select count(Hostelid)+1 from student");
        String id="H"+new SimpleDateFormat("ddMMyyy").format(new Date())+getValue;
        return id;
        }
    
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
        HostelID hos= new HostelID();
        String s=hos.getID();
        System.out.println(s);
    
    }
    
}
