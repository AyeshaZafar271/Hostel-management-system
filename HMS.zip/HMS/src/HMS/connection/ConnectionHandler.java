/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HMS.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Ayesha Zafar
 */
public class ConnectionHandler {
        Connection  	con;
    
    String	 	dbUrl;
    String		username;
    String		password;
    
    public Connection getConnection() throws Exception
    {
        
       try {
            String fullString=new String();
            Class.forName("com.mysql.jdbc.Driver");
            dbUrl= "jdbc:mysql://localhost/HMS";
            username="root";
            password="";
            
            
            con = DriverManager.getConnection(dbUrl,username,password);
            System.out.println("Connected to the server!");
        }

    catch(Exception cnfEx) {
          System.out.println("exception in connection Handler ");
    }
     System.out.println("Connected");
       return con;
    }
    
    public void releaseResources()throws Exception{
        try {
            con.close();
        } 
        catch(SQLException sqlEx) {
            System.out.println("SQL Exception: " + sqlEx);
            throw sqlEx;
        }
    }
}
